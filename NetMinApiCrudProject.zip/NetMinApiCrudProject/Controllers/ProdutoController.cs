using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]
public class ProdutoController : Controller
{
    private readonly ProductDbContext _context;
    public ProdutoController(ProductDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult ObterTodos()
    {
        return Ok(_context.Produtos.ToList());
    }
    [HttpGet]
    public IActionResult ObterTodosFiltro()
    {
        //TODO:1
        var listaDTO = new List<ProdutoDTO>();
        foreach (var item in _context.Produtos.ToList())
        {
            listaDTO.Add(new ProdutoDTO { Nome = item.Nome, PrecoUnitario = item.PrecoUnitario });
        }

        return Ok();
    }

    [HttpPost]
    public IActionResult Inserir(ProdutoDTO model)
    {
        _context.Produtos.Add(new Produto { Nome = model.Nome, PrecoUnitario = model.PrecoUnitario });
        _context.SaveChanges();
        return Ok();
    }

    [HttpPut("{id}")]
    public IActionResult Atulizar(int id, ProdutoDTO model)
    {
        var result = _context.Produtos.Find(id);
        result.Nome = model.Nome;
        result.PrecoUnitario = model.PrecoUnitario;
        _context.SaveChanges();
        return Ok();
    }

    [HttpDelete("{id}")]
    public IActionResult Deletar(int id)
    {
        var result = _context.Produtos.Find(id);
        _context.Remove(result);
        _context.SaveChanges();
        return Ok();
    }
}