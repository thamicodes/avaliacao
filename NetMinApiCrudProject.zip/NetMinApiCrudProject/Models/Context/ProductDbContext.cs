using Microsoft.EntityFrameworkCore;

public class ProductDbContext : DbContext
{
    public ProductDbContext(DbContextOptions context) : base(context)
    {
    }
    public DbSet<Produto> Produtos { get; set; }
    //Criar Categoria para os Produtos
    //Fazer CRUD de Categoria com filtros
    //Retornar em um objeto DTO
}

