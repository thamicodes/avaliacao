public class ProdutoDTO{
public string Nome { get; set; }
public double PrecoUnitario { get; set; }
}